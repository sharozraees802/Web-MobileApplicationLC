var myQuestions = [
    {
        question : "what is your name",
        answer : {
            a : "ali",
            b : "ghous",
            c : "basit"
        },
        correctAnswer : "c"
    },
    {
        question : "what is your age",
        answer : {
            a : 15,
            b : 12,
            c : 16
        },
        correctAnswer : "b"
    },
]